<?php
namespace App\Models;

//include_once "DBAbstractModel.php";

class Usuarios extends DBAbstractModel
{
    private $id;
    private $nombre;
    private $password;

    private static $instance;

    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
        }
        return self::$instance;
    }

    public function login($usuario, $password) {
        $this->query = "
                SELECT *
                FROM usuario
                WHERE usuario = :usuario and
                      password = :password";
        $this->parameters['usuario'] = $usuario;
        $this->parameters['password'] = $password;

        $this->get_results_from_query();
        if( count($this->rows) == 1 ){
            foreach ($this->rows[0] as $propiedad=>$valor) {
                $this->$propiedad=$valor;
            }
            $this->mensaje = 'sh encontrado';            
        } else {
            echo "Contacto no encontrado";
        }
        return $this->rows[0]??null;
    }

    public function get($id){}

    public function set() {}

    public function read() {}

    public function readAll() {}

    public function insert() {}

    public function update() {}

    public function delete() {}

    public function edit() {}


}
