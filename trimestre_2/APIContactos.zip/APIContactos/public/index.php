<?php
require "../bootstrap.php";
echo DBHOST;
?>