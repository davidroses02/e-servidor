<?php
namespace App\Models;

//include_once "DBAbstractModel.php";

class Contactos extends DBAbstractModel
{
    private $id;
    private $nombre;
    private $email;
    private $telefono;
    private $created_at;
    private $updated_at;
    private static $instance;

    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
        }
        return self::$instance;
    }

    public function get($id) {
        $this->query="SELECT * FROM contactos WHERE id=$id";
        $this->get_results_from_query();
        if( count($this->rows)==1 ){
            foreach ($this->rows[0] as $propiedad=>$valor) {
                $this->$propiedad=$valor;
            }
        } else {
            echo "Contacto no encontrado";
        }
        return $this->rows[0]??null;
    }

    public function set() {}

    public function read() {}

    public function readAll() {}

    public function insert() {}

    public function update() {}

    public function delete() {}

    public function edit() {}


}

?>